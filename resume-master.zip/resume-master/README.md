# Resume [![resume](https://img.shields.io/badge/example-pdf-green.svg)](https://sadmansk.com/resume.pdf) [![build status](https://git.sadmansk.com/sadmansk/resume/badges/master/build.svg)](https://git.sadmansk.com/sadmansk/resume/commits/master)

## Setup

You need to download the full `texlive` package for your OS. More specific instructions coming soon.
Once the full `texlive` suite is available, run:
```
$ xelatex resume-cv.tex
```
And the pdf will be save as `resume.pdf`.

> Note: If the build is running, the image below and the pdf link above will be 
broken. So please recheck after 15 minutes.

![Resume Image](https://sadmansk.com/resume.png)
